package com.graph.graph;

public class DayRangeOccurrences {
	private int dayRange;
    private int occurrences;

    // Constructor
    public DayRangeOccurrences(int dayRange, int occurrences) {
        this.dayRange = dayRange;
        this.occurrences = occurrences;
    }

	public int getDayRange() {
		return dayRange;
	}

	public void setDayRange(int dayRange) {
		this.dayRange = dayRange;
	}

	public int getOccurrences() {
		return occurrences;
	}

	public void setOccurrences(int occurrences) {
		this.occurrences = occurrences;
	}

	
}
