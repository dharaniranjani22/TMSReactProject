package com.graph.graph;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
public class GraphService {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<String> fetchDaysDifferenceData() {
        String query = "SELECT DAYS_DIFFERENCE AS DAY_RANGE, COUNT(*) AS OCCURRENCES FROM (SELECT ABS(EXTRACT(DAY FROM (TO_TIMESTAMP(CREATED_DATE, 'DD-MM-RR HH:MI:SS.FF9 AM') - TO_TIMESTAMP(TR_START_DATE, 'DD-MM-RR HH:MI:SS.FF9 AM')))) AS DAYS_DIFFERENCE  FROM T_TRAVEL_REQ_HDR WHERE CREATED_DATE IS NOT NULL AND TR_START_DATE IS NOT NULL) SUBQUERY GROUP BY DAYS_DIFFERENCE ORDER BY DAYS_DIFFERENCE";

        List<String> result = namedParameterJdbcTemplate.query(query, (rs, rowNum) -> {
            int dayRange = rs.getInt("DAY_RANGE");
            int occurrences = rs.getInt("OCCURRENCES");
            String resultString = dayRange + " " + "occurrences"+occurrences;
            System.out.println(resultString);
            return resultString;
        });

        return result;
    }
    
    
    public List<ReqTypeOccurrences> fetchReqTypeOccurrences() {
        String query = "SELECT Req_type, COUNT(*) AS OCCURRENCES FROM t_travel_req_hdr GROUP BY Req_type";

        List<ReqTypeOccurrences> result = namedParameterJdbcTemplate.query(query, (rs, rowNum) -> {
            String reqType = rs.getString("Req_type");
            int occurrences = rs.getInt("OCCURRENCES");
            return new ReqTypeOccurrences(reqType, occurrences);
        });

        return result;
    }

}
