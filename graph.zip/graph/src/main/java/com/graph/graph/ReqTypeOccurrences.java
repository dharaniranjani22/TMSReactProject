package com.graph.graph;

public class ReqTypeOccurrences {
    private String reqType;
    private int occurrences;

    // Constructor
    public ReqTypeOccurrences(String reqType, int occurrences) {
        this.reqType = reqType;
        this.occurrences = occurrences;
    }

    // Getters and setters
    public String getReqType() {
        return reqType;
    }

    public void setReqType(String reqType) {
        this.reqType = reqType;
    }

    public int getOccurrences() {
        return occurrences;
    }

    public void setOccurrences(int occurrences) {
        this.occurrences = occurrences;
    }
}
