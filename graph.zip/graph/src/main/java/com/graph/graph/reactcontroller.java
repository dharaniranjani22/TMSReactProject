package com.graph.graph;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@CrossOrigin(origins = "http://localhost:5187/")
@RequestMapping(value="/api")
public class reactcontroller {
    
    @Autowired
    private GraphService graphService;

    @GetMapping(value = "/dayRangeOccurrences", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<String> fetchDaysDifferenceData() {
    	
        return graphService.fetchDaysDifferenceData();
        
        
    }
    
    @GetMapping(value = "/reqTypeOccurrences", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ReqTypeOccurrences> fetchReqTypeOccurrences() {
        return graphService.fetchReqTypeOccurrences();
    }

}
